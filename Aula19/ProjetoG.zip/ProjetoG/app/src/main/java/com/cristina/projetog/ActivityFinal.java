package com.cristina.projetog;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public class ActivityFinal extends AppCompatActivity {
    Button btnSair, btnReiniciar;
    TextView txtPontosFinal;
    VideoView vdvFinal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_final);

        btnSair = findViewById(R.id.btnSair);
        btnReiniciar = findViewById(R.id.btnReiniciar);
        txtPontosFinal = findViewById(R.id.txtPontosFinal);
        vdvFinal = findViewById(R.id.vdvFinal);

        //parar a música
        MainActivity.mp.stop();

        //vinculo caso video é necessario criar o caminho
        //via uri com android.resource:// sempre o mesmo
        //getpacketname -- nome do projeto
        //qdo trabalhar com vídeo sempre desta forma
        if(MainActivity.acertos == 3) {
            Uri caminho = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.bonus);
            vdvFinal.setVideoURI(caminho);
            vdvFinal.start();
        }

        txtPontosFinal.setText("Pontos Atuais: " + MainActivity.acertos++);


        btnSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

            }
        });

        btnReiniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.acertos = 0;
                abrirMain();

            }
        });


    }
    private void abrirMain(){
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
        finish();
    }

    //desativar btn voltar sobrescrito p anular a volta
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Você não pode voltar", Toast.LENGTH_LONG).show();
    }
}