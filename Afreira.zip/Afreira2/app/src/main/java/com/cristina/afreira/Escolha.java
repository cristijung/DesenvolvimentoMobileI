package com.cristina.afreira;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

public class Escolha extends AppCompatActivity {
    private TextView resposta;
    private Button btnTeaser, btnSom;
    private WebView imagens;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escolha);
        //MainActivity.mp.stop();

        resposta = findViewById(R.id.resposta);
        btnSom = findViewById(R.id.btnSom);
        btnTeaser = findViewById(R.id.btnTeaser);
        imagens = findViewById(R.id.imagens);

        String recebe = getIntent().getStringExtra("dados");
        resposta.setText(recebe);

        WebSettings gif = imagens.getSettings();
        gif.setJavaScriptEnabled(true);
        String caminho = "file:android_asset/terror.gif";
        imagens.loadUrl(caminho);

        btnSom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirSom();
            }
        });

        btnTeaser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirTeaser();
            }
        });

    }
    public void abrirSom() {
        Intent janelas = new Intent(this, Som.class);
        startActivity(janelas);
    }

    public void abrirTeaser() {
        Intent janelat = new Intent(this, Teaser.class);
        startActivity(janelat);

    }

}