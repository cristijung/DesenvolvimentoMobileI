package com.cristina.afreira;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Som extends AppCompatActivity {
    private Button btnVoltars;
    private MediaPlayer som;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_som);

        btnVoltars = findViewById(R.id.btnVoltars);
        som = MediaPlayer.create(this, R.raw.corredor);
        som.start();

        btnVoltars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });
    }

    public void abrirVoltar() {
        Intent janela = new Intent(this, Escolha.class);
        startActivity(janela);
        som.stop();
    }
}