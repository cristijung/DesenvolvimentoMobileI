package com.cristina.terror;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Musica extends AppCompatActivity {
    private TextView respostac;
    private Button btnVoltar2;
    private MediaPlayer som;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_musica);

        respostac = findViewById(R.id.respostac);
        btnVoltar2 = findViewById(R.id.btnVoltart2);
        som = MediaPlayer.create(this, R.raw.corredor);
        som.start();

        String recebe = getIntent().getStringExtra("dados");
        respostac.setText(recebe);

        btnVoltar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                voltar();
            }
        });
    }

    public void voltar() {
        Intent janelav = new Intent(this, MainActivity.class);
        startActivity(janelav);
    }
}