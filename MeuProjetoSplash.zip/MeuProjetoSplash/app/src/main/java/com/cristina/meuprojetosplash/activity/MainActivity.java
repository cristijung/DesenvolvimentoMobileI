package com.cristina.meuprojetosplash.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.cristina.meuprojetosplash.R;
import com.cristina.meuprojetosplash.fragments.AlbumFragment;
import com.cristina.meuprojetosplash.fragments.MusicaFragment;

public class MainActivity extends AppCompatActivity {
    private Button btnAlbum, btnMusica;
    private AlbumFragment albumFragment;
    private MusicaFragment musicaFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAlbum = findViewById(R.id.btnAlbum);
        btnMusica = findViewById(R.id.btnMusica);
        albumFragment = new AlbumFragment();
        musicaFragment = new MusicaFragment();

        btnMusica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.add(R.id.frameconteudo,musicaFragment);
                transaction.commit();

            }
        });

        btnAlbum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.add(R.id.frameconteudo,albumFragment);
                transaction.commit();
            }
        });





    }
}