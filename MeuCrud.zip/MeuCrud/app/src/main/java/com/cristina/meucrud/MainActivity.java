package com.cristina.meucrud;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ListView;

import com.cristina.meucrud.modelo.Pessoa;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

import static com.cristina.meucrud.R.menu.main_meni;

public class MainActivity extends AppCompatActivity {
    EditText editNome, editEmail;
    ListView listaDados;


    //é preciso configurar as dependências do firease, clicar na lampada.
    //esta dependência é importante, pois é ela que dá referência p a conexão
    FirebaseDatabase firebasedatabase;
    DatabaseReference databasereference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editEmail = findViewById(R.id.editEmail);
        editNome = findViewById(R.id.editNome);
        listaDados = findViewById(R.id.listaDados);

        inicializarFirebase();
        //eventoDataBase();


    }
    public void inicializarFirebase()
    {
        FirebaseApp.initializeApp(MainActivity.this);
        firebasedatabase = FirebaseDatabase.getInstance();
        databasereference = firebasedatabase.getReference();
    }

    //chamar o menu
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.main_meni, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //inserindo ação para put dados no banco de dados
    public boolean onOptionsItemSelected(MenuItem item)
    {
       int id = item.getItemId();
       //ao clicar em add
        if(id == R.id.editNome) ///mudar aqui
        {
            Pessoa p = new Pessoa();
            p.setId(UUID.randomUUID().toString());
            p.setNome(editNome.getText().toString());
            p.setEmail(editEmail.getText().toString());
            databasereference.child("Pessoa").child(p.getId()).setValue(p);
            limparCampos();

        }
        return  true;
            }
            public void limparCampos()
            {
                editNome.setText("");
                editEmail.setText("");
            }
}