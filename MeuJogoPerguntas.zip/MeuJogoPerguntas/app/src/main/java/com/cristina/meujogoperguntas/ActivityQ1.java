package com.cristina.meujogoperguntas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ActivityQ1 extends AppCompatActivity {
    Button btnOpcao1Q1, btnOpcao2Q1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q1);
        /*
        Dentro do onCreate chamamos a variável mp que possui importação
        da classe MediaPlayer e caminho para execução do arquivo fundo.mp4,
        dentro da pasta raw.
        Chamamos a Activity que tem a variável e associamos ao método start;
         */
        MainActivity.mp.start();

        btnOpcao1Q1 = findViewById(R.id.btnOpcao1Q1);
        btnOpcao2Q1 = findViewById(R.id.btnOpcao1Q2);

        btnOpcao1Q1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirQ2();
            }
        });

        btnOpcao2Q1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirQ2();
            }
        });

    }

    private void abrirQ2() {
        Intent janela = new Intent(this, ActivityQ2.class);
        startActivity(janela);
        finish();
    }

    //desativar btn voltar em qualquer nível
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Você não pode voltar o jogo", Toast.LENGTH_LONG).show();
    }

}